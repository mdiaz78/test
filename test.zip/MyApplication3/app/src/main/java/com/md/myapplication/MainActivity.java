package com.md.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private String TAG = MainActivity.class.getSimpleName();

    private Spinner spMagnitud;
    private EditText etDateStart, etDateFinal;
    private ImageButton ibtnStart, ibtnEnd;
    private Button btnConsultar, btnStored;
    private int mYear, mMonth, mDay;

    private RequestQueue  mRequestQueue;
    private StringRequest mStringRequest;
    private String        url = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        assignViews();

    }

    /**
     * Asignacion de vistas a objetos
     */
    private void assignViews() {
        spMagnitud=(Spinner) findViewById(R.id.sp_magnitud);
        String[] items = new String[]{"5.0","5.5","6.0","6.5"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
              (this,android.R.layout.simple_spinner_item, items);
        spMagnitud.setAdapter(adapter);

        etDateStart = (EditText) findViewById(R.id.date_start);
        etDateFinal = (EditText) findViewById(R.id.date_final);

        ibtnStart = (ImageButton) findViewById(R.id.ibtn_start);
        ibtnStart.setOnClickListener(this);
        ibtnEnd = (ImageButton) findViewById(R.id.ibtn_end);
        ibtnEnd.setOnClickListener(this);

        btnStored = (Button) findViewById(R.id.btn_datos_guardados);
        btnStored.setOnClickListener(this);
        btnConsultar = (Button) findViewById(R.id.btn_consultar);
        btnConsultar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if(v.getId() == R.id.ibtn_start){
            Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                  new DatePickerDialog.OnDateSetListener() {

                      @Override
                      public void onDateSet(DatePicker view, int year,
                                            int monthOfYear, int dayOfMonth) {

                          String dia="";
                          if(dayOfMonth<10){
                              dia = "0" + dayOfMonth;
                          } else {
                              dia= ""+dayOfMonth;
                          }

                          String mes="";
                          monthOfYear=monthOfYear+1;
                          if((monthOfYear)<10){
                              mes = "0" + monthOfYear;
                          } else {
                              mes=""+monthOfYear;
                          }

                          etDateStart.setText(year + "-" + mes + "-" + dia);

                      }
                  }, mYear, mMonth, mDay);
            datePickerDialog.show();

        }

        if(v.getId() == R.id.ibtn_end){
            Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                  new DatePickerDialog.OnDateSetListener() {

                      @Override
                      public void onDateSet(DatePicker view, int year,
                                            int monthOfYear, int dayOfMonth) {

                          String dia="";
                          if(dayOfMonth<10){
                              dia = "0" + dayOfMonth;
                          } else {
                              dia= ""+dayOfMonth;
                          }

                          String mes="";
                          monthOfYear=monthOfYear+1;
                          if((monthOfYear)<10){
                              mes = "0" + monthOfYear;
                          } else {
                              mes=""+monthOfYear;
                          }

                          etDateFinal.setText(year + "-" + mes + "-" + dia);

                      }
                  }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }

        if(v.getId() == R.id.btn_datos_guardados){
            Log.d(TAG, "onClick: Datos Almacenados");

        }

        if(v.getId() == R.id.btn_consultar){
            Log.d(TAG, "onClick: Consultar");

            request(etDateStart.getText().toString(),
                  etDateFinal.getText().toString(),
                  spMagnitud.getSelectedItem().toString());

        }

    }

    private void request(String starttime, String endtime, String minmagnitude){
        //RequestQueue initialized
        mRequestQueue = Volley.newRequestQueue(this);

        url = url+"&starttime="+starttime+"&endtime="+endtime+"&minmagnitude="+minmagnitude;

        //String Request initialized
        mStringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                //Log.d(TAG, "onResponse: " + response.toString());

                showMap(response.toString());

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Log.i(TAG,"Error :" + error.toString());
            }
        });

        mRequestQueue.add(mStringRequest);
    }

    private void showMap(String respuesta){
        Intent intent = new Intent(MainActivity.this, MapActivity.class);
        intent.putExtra("response", respuesta);
        if(null != getIntent().getExtras()){
            intent.putExtras(getIntent().getExtras());
        }
        startActivity(intent);
    }
}